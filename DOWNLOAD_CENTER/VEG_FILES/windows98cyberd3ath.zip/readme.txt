By KonaloboStudio 
https://www.youtube.com/KonaloboStudio
https://konalobostudio.github.io/

(RECREATION)(VEG PROJECT) Windows 98 - Sparta CyberD3ath Remix
ПОЛНОЕ РЕСОЗДАНИЕ старого ремикса от CatmanTeam. Полностью сделан в Sony Vegas 10. Как всегда сурсы и прочие материалы в комплекте
УКАЗЫВАЙТЕ МЕНЯ КАК СОЗДАТЕЛЯ ФАЙЛА


(RECREATION)(VEG PROJECT) Windows 98 - Sparta CyberD3ath Remix
FULL RE-CREATION of the old remix from CatmanTeam. Completely made in Sony Vegas 10. As always, resources and other materials included
CREDIT ME AS THE CREATOR OF THE FILE